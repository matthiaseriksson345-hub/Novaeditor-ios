import SwiftUI
import GLKit

/// Minimal single-pass renderer for Nova effects (OpenGL ES 3.0, same GLSL dialect as Android).
final class EffectGLView: GLKView {
    var effect: Effect? { didSet { needsRebuild = true } }
    var values: [String: [Float]] = [:]
    var image: UIImage? { didSet { needsTexture = true } }
    private(set) var lastError: String?
    var onError: ((String?) -> Void)?

    private var program: GLuint = 0
    private var texture: GLuint = 0
    private var needsRebuild = true, needsTexture = true
    private var link: CADisplayLink?
    private let start = CACurrentMediaTime()

    init() {
        super.init(frame: .zero, context: EAGLContext(api: .openGLES3)!)
        enableSetNeedsDisplay = false
        link = CADisplayLink(target: self, selector: #selector(tick))
        link?.add(to: .main, forMode: .common)
    }
    required init?(coder: NSCoder) { fatalError() }
    deinit { link?.invalidate() }
    @objc private func tick() { display() }

    private static let vertex = """
    #version 300 es
    out vec2 acScreenNorm;
    void main() {
        vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
        acScreenNorm = p;
        gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
    }
    """

    private func fragmentSource(_ e: Effect) -> String {
        var s = """
        #version 300 es
        precision highp float; precision highp int; precision highp sampler2D;
        in vec2 acScreenNorm;
        out vec4 fragColor;
        uniform vec2 acScreenSize; uniform vec2 acLayerSize; uniform vec2 acResolution;
        uniform vec2 acTamanhoDaTela; uniform vec2 acTamanhoDaCamada; uniform vec2 acTexelSize;
        uniform float acTime; uniform float acAspect; uniform int acPass;
        #define acLayerNorm acScreenNorm
        #define acTela acScreenNorm

        """
        for t in e.textures { s += "uniform sampler2D \(t);\n" }
        for p in e.params {
            switch p.kind {
            case .slider, .spinner: s += "uniform float \(p.id);\n"
            case .color: s += "uniform vec4 \(p.id);\n"
            case .switch: s += "uniform bool \(p.id);\n"
            case .selector: s += "uniform int \(p.id);\n"
            case .point: s += "uniform vec2 \(p.id);\n"
            case .xyz, .orient: s += "uniform vec3 \(p.id);\n"
            }
        }
        return s + e.shader
    }

    private func compile(_ type: GLenum, _ src: String) -> GLuint? {
        let sh = glCreateShader(type)
        src.withCString { var p: UnsafePointer<GLchar>? = $0; glShaderSource(sh, 1, &p, nil) }
        glCompileShader(sh)
        var ok: GLint = 0; glGetShaderiv(sh, GLenum(GL_COMPILE_STATUS), &ok)
        if ok == 0 {
            var len: GLint = 0; glGetShaderiv(sh, GLenum(GL_INFO_LOG_LENGTH), &len)
            var log = [GLchar](repeating: 0, count: Int(len) + 1)
            glGetShaderInfoLog(sh, len, nil, &log)
            lastError = String(cString: log); return nil
        }
        return sh
    }

    private func rebuild() {
        needsRebuild = false; lastError = nil
        if program != 0 { glDeleteProgram(program); program = 0 }
        guard let e = effect else { return }
        if e.multiPass { lastError = "Multi-pass effects are not supported in this preview yet." }
        else if let vs = compile(GLenum(GL_VERTEX_SHADER), Self.vertex),
                let fs = compile(GLenum(GL_FRAGMENT_SHADER), fragmentSource(e)) {
            let p = glCreateProgram()
            glAttachShader(p, vs); glAttachShader(p, fs); glLinkProgram(p)
            var ok: GLint = 0; glGetProgramiv(p, GLenum(GL_LINK_STATUS), &ok)
            if ok != 0 { program = p } else { lastError = "Link failed" }
        }
        let msg = lastError
        DispatchQueue.main.async { self.onError?(msg) }
    }

    private func uploadTexture() {
        needsTexture = false
        guard let cg = image?.cgImage else { return }
        if texture != 0 { glDeleteTextures(1, &texture) }
        if let t = try? GLKTextureLoader.texture(with: cg, options: [GLKTextureLoaderOriginBottomLeft: true]) {
            texture = t.name
            glBindTexture(GLenum(GL_TEXTURE_2D), texture)
            glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR)
            glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_LINEAR)
        }
    }

    override func draw(_ rect: CGRect) {
        EAGLContext.setCurrent(context)
        if needsRebuild { rebuild() }
        if needsTexture { uploadTexture() }
        glClearColor(0.07, 0.07, 0.08, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        guard program != 0, let e = effect else { return }
        glUseProgram(program)
        let w = Float(drawableWidth), h = Float(drawableHeight)
        func u(_ n: String) -> GLint { glGetUniformLocation(program, n) }
        for n in ["acScreenSize", "acLayerSize", "acResolution", "acTamanhoDaTela", "acTamanhoDaCamada"] { glUniform2f(u(n), w, h) }
        glUniform2f(u("acTexelSize"), 1 / w, 1 / h)
        glUniform1f(u("acTime"), Float(CACurrentMediaTime() - start))
        glUniform1f(u("acAspect"), w / h)
        glUniform1i(u("acPass"), 0)
        glActiveTexture(GLenum(GL_TEXTURE0))
        glBindTexture(GLenum(GL_TEXTURE_2D), texture)
        for t in e.textures { glUniform1i(u(t), 0) }
        for p in e.params {
            let v = values[p.id] ?? p.def, loc = u(p.id)
            guard loc >= 0 else { continue }
            switch p.kind {
            case .slider, .spinner: glUniform1f(loc, v[0])
            case .color: glUniform4f(loc, v[0], v[1], v[2], v.count > 3 ? v[3] : 1)
            case .switch, .selector: glUniform1i(loc, GLint(v[0]))
            case .point: glUniform2f(loc, v[0], v.count > 1 ? v[1] : 0.5)
            case .xyz, .orient: glUniform3f(loc, v[0], v.count > 1 ? v[1] : 0, v.count > 2 ? v[2] : 0)
            }
        }
        glDrawArrays(GLenum(GL_TRIANGLES), 0, 3)
    }
}

struct EffectPreview: UIViewRepresentable {
    let effect: Effect
    let values: [String: [Float]]
    let image: UIImage
    @Binding var error: String?

    func makeUIView(context: Context) -> EffectGLView {
        let v = EffectGLView()
        v.onError = { e in error = e }
        v.effect = effect; v.image = image
        return v
    }
    func updateUIView(_ v: EffectGLView, context: Context) {
        v.values = values
        if v.image !== image { v.image = image }
    }
}
