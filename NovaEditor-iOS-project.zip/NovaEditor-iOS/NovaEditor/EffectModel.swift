import Foundation

struct EffectParam: Identifiable {
    enum Kind: String { case slider, spinner, color, `switch`, selector, point, xyz, orient }
    let id: String
    let kind: Kind
    let label: String
    var def: [Float]
    var min: Float
    var max: Float
}

struct Effect: Identifiable {
    let id: String
    var name = ""
    var desc = ""
    var category = ""
    var textures: [String] = []
    var params: [EffectParam] = []
    var shader = ""
    var multiPass = false
    var fileName = ""
}

/// Parses the Nova effect XML (params + GLSL ES 3.00 fragment shader).
final class EffectParser: NSObject, XMLParserDelegate {
    private var effect = Effect(id: "")
    private var inShader = false
    private var buffer = ""

    static func parse(url: URL) -> Effect? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        let p = XMLParser(data: data)
        let d = EffectParser()
        p.delegate = d
        guard p.parse(), !d.effect.id.isEmpty else { return nil }
        d.effect.fileName = url.lastPathComponent
        return d.effect
    }

    func parser(_ parser: XMLParser, didStartElement el: String, namespaceURI: String?,
                qualifiedName: String?, attributes a: [String: String]) {
        switch el {
        case "effect":
            effect = Effect(id: a["id"] ?? "")
            effect.name = a["name-en"] ?? a["name"] ?? effect.id
            effect.desc = a["desc-en"] ?? a["desc"] ?? ""
            effect.category = a["category"] ?? ""
        case "pass": effect.multiPass = true
        case "texture": if let i = a["id"] { effect.textures.append(i) }
        case "shader": inShader = true; buffer = ""
        default:
            guard let id = a["id"], let kind = EffectParam.Kind(rawValue: el) else { return }
            let f = { (k: String, d: Float) in Float(a[k] ?? "") ?? d }
            var def: [Float] = [f("default", 0)]
            switch kind {
            case .point: def = [f("defaultX", 0.5), f("defaultY", 0.5)]
            case .switch: def = [a["default"] == "true" ? 1 : 0]
            case .color: def = Self.hex(a["default"] ?? "#FFFFFF")
            case .xyz, .orient: def = [f("defaultX", 0), f("defaultY", 0), f("defaultZ", 0)]
            default: break
            }
            effect.params.append(EffectParam(id: id, kind: kind,
                label: a["label-en"] ?? a["label"] ?? id,
                def: def, min: f("min", 0), max: f("max", 1)))
        }
    }

    func parser(_ parser: XMLParser, foundCDATA data: Data) {
        if inShader { buffer += String(decoding: data, as: UTF8.self) }
    }
    func parser(_ parser: XMLParser, didEndElement el: String, namespaceURI: String?, qualifiedName: String?) {
        if el == "shader" { inShader = false; effect.shader += buffer + "\n" }
    }

    /// "#RRGGBB" or "#AARRGGBB" -> [r,g,b,a]
    static func hex(_ s: String) -> [Float] {
        var h = s.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        if h.count == 6 { h = "FF" + h }
        guard h.count == 8, let v = UInt32(h, radix: 16) else { return [1, 1, 1, 1] }
        return [Float((v >> 16) & 255) / 255, Float((v >> 8) & 255) / 255,
                Float(v & 255) / 255, Float((v >> 24) & 255) / 255]
    }
}

enum EffectLibrary {
    static func loadAll() -> [Effect] {
        guard let dir = Bundle.main.url(forResource: "effects", withExtension: nil),
              let files = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)
        else { return [] }
        return files.filter { $0.pathExtension == "xml" }
            .compactMap(EffectParser.parse)
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
}
