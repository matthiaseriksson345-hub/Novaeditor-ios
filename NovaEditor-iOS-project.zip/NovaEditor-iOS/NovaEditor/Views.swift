import SwiftUI
import PhotosUI

struct EffectListView: View {
    @State private var effects: [Effect] = []
    @State private var query = ""

    var body: some View {
        NavigationStack {
            List(filtered) { e in
                NavigationLink(value: e.id) {
                    VStack(alignment: .leading) {
                        Text(e.name).font(.headline)
                        Text(e.category).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Nova Effects (\(effects.count))")
            .navigationDestination(for: String.self) { id in
                if let e = effects.first(where: { $0.id == id }) { EffectDetailView(effect: e) }
            }
            .searchable(text: $query)
        }
        .task { effects = EffectLibrary.loadAll() }
    }
    private var filtered: [Effect] {
        query.isEmpty ? effects : effects.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }
}

struct EffectDetailView: View {
    let effect: Effect
    @State private var values: [String: [Float]] = [:]
    @State private var error: String?
    @State private var picked: PhotosPickerItem?
    @State private var image = EffectDetailView.sample()

    var body: some View {
        VStack(spacing: 0) {
            EffectPreview(effect: effect, values: values, image: image, error: $error)
                .aspectRatio(image.size.width / image.size.height, contentMode: .fit)
            if let error { Text(error).font(.caption2).foregroundStyle(.red).padding(6) }
            Form {
                PhotosPicker("Choose image", selection: $picked, matching: .images)
                ForEach(effect.params) { p in ParamRow(p: p, values: $values) }
            }
        }
        .navigationTitle(effect.name).navigationBarTitleDisplayMode(.inline)
        .onChange(of: picked) { item in
            Task {
                if let d = try? await item?.loadTransferable(type: Data.self), let i = UIImage(data: d) { image = i }
            }
        }
    }

    static func sample() -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 1024, height: 576)).image { c in
            let cs = CGColorSpaceCreateDeviceRGB()
            let g = CGGradient(colorsSpace: cs, colors: [UIColor.systemPink.cgColor, UIColor.systemBlue.cgColor,
                                                         UIColor.black.cgColor, UIColor.white.cgColor] as CFArray,
                               locations: [0, 0.4, 0.7, 1])!
            c.cgContext.drawLinearGradient(g, start: .zero, end: CGPoint(x: 1024, y: 576), options: [])
        }
    }
}

struct ParamRow: View {
    let p: EffectParam
    @Binding var values: [String: [Float]]
    private var v: [Float] { values[p.id] ?? p.def }

    var body: some View {
        switch p.kind {
        case .slider, .spinner:
            VStack(alignment: .leading) {
                Text("\(p.label): \(v[0], specifier: "%.2f")").font(.caption)
                Slider(value: Binding(get: { Double(v[0]) }, set: { values[p.id] = [Float($0)] }),
                       in: Double(p.min)...Double(max(p.max, p.min + 0.001)))
            }
        case .switch:
            Toggle(p.label, isOn: Binding(get: { v[0] > 0 }, set: { values[p.id] = [$0 ? 1 : 0] }))
        case .selector:
            Stepper("\(p.label): \(Int(v[0]))", value: Binding(get: { Int(v[0]) }, set: { values[p.id] = [Float($0)] }), in: 0...20)
        case .color:
            ColorPicker(p.label, selection: Binding(
                get: { Color(.sRGB, red: Double(v[0]), green: Double(v[1]), blue: Double(v[2]), opacity: Double(v[3])) },
                set: { c in
                    var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                    UIColor(c).getRed(&r, green: &g, blue: &b, alpha: &a)
                    values[p.id] = [Float(r), Float(g), Float(b), Float(a)]
                }))
        default:
            EmptyView()  // point / xyz / orient: add on-canvas handles later
        }
    }
}
