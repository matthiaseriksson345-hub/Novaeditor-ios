# NovaEditor for iOS (starter port)

This is NOT an automatic conversion of the APK. It is a native iOS starter that reuses the APK's
platform-independent assets (1,609 GLSL effect XMLs, fonts, textures, looks, templates, i18n) and
runs the effects with an OpenGL ES 3.0 renderer.

## Build an IPA
**Mac:** `brew install xcodegen && xcodegen generate && open NovaEditor.xcodeproj` -> set your Team -> Run/Archive.
**No Mac:** push this folder to a GitHub repo; the included workflow (`.github/workflows/build-ipa.yml`)
builds `NovaEditor-unsigned.ipa` on a macOS runner. Sign/install it with AltStore, Sideloadly, or your Apple ID.

## Done
- Effect XML parser (params + shader), effect browser/search, live preview with parameter controls.
- Single-pass effects with `acScreenNorm`, `acScreenSize`, `acLayerSize`, `acTime`, `acAspect`, `acPass`.

## Not done (needs the original Kotlin source)
- Timeline / video decode & export (AVFoundation), project format, UI of the real editor.
- Multi-pass effects (417 of them use `<pass>`), other `ac*` built-ins, point/xyz/orient handles,
  `.novatemplate` loader, the ONNX AI features (`assets/ia`, 21 MB, not bundled), Python/QuickJS/Discord libs.
- Not compiled or tested here (no Xcode in this sandbox) - expect small fixes on first build.
- GLES is deprecated by Apple; port the renderer to Metal (translate GLSL via SPIRV-Cross) for the long term.
